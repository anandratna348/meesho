
const filterData = ['Category','Gender','Fabric','Oxfords','dail_shape','Color','Price','Meesho Mall',
'Occasion']

export default filterData