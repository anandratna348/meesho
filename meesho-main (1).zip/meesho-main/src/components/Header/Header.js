import React from "react"
import FirstHeader from "./FirstHeader"
import SecondHeader from "./SecondHeader"

export default function Header() {
  
  return (
    <>
    <FirstHeader/>
    <SecondHeader/>
    </>
    
  )
}
