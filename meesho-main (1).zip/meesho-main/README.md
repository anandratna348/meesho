# meesho
This is a meesho clone website. In which I am using technology React.js. This tech is to make website to fast and optimised . 
This is live link of the website -  https://ephemeral-custard-e192f3.netlify.app/
